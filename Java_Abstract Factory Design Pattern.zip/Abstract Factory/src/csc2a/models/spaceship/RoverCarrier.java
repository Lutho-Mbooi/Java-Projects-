/**
 * 
 */
package csc2a.models.spaceship;

import java.util.ArrayList;

import csc2a.models.rover.Rover;

/**
 * @author Lutho Mbooi
 * @version P07
 * @since 2023
 * 
 *
 */
public class RoverCarrier extends Spaceship implements SpaceshipVehicle {

	private ArrayList<Rover> rovers;
	/**
	 * @param manned
	 */
	public RoverCarrier(boolean manned) {
		super(manned);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * 
	 * @return rovers
	 */
	public ArrayList<Rover> getRovers() {
        return rovers;
    }

	/**
	 * 
	 * @param rovers
	 */
    public void setRovers(ArrayList<Rover> rovers) {
        this.rovers = rovers;
    }


	@Override
	public void fly() {
		
		System.out.println("Rover carrier spaceship is flying with " + rovers.size() + " rovers on board");
	}

}
