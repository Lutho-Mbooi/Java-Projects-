/**
 * 
 */
package csc2a.models.spaceship;

/**
 * @author Lutho Mbooi
 * @version P07_2023
 * @since 2024
 * 
 *
 */
public interface SpaceshipVehicle {
	
	void fly();

}
