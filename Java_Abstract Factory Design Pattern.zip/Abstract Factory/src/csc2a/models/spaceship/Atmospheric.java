/**
 * 
 */
package csc2a.models.spaceship;

import csc2a.models.rover.E_PLANET;

/**
 * @author Lutho Mbooi
 * @version P07_2023
 * @since 2024
 * 
 *
 */
public class Atmospheric extends Spaceship implements SpaceshipVehicle {

	 private int numSensors;
	    private E_PLANET planet;
	    
	    
	/**
	 * @param manned
	  
	 */
	public Atmospheric(boolean manned) {
		super(manned);
		
		
	}

	

	/**
	 * @return the numSensors
	 */
	public int getNumSensors() {
		return numSensors;
	}

	/**
	 * @param numSensors
	 * 			 the numSensors to set
	 */
	public void setNumSensors(int numSensors) {
		this.numSensors = numSensors;
	}

	/**
	 * @return the planet
	 */
	public E_PLANET getPlanet() {
		return planet;
	}

	/**
	 * @param planet 
	 * 			the planet to set
	 */
	public void setPlanet(E_PLANET planet) {
		this.planet = planet;
	}
	
	@Override
	public void fly() {
		
		System.out.println("Atmospheric spaceship is flying with " + numSensors + " sensors to explore " + planet);
	}

}
