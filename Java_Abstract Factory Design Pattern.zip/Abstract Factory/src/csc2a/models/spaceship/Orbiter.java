/**
 * 
 */
package csc2a.models.spaceship;

import csc2a.models.rover.E_PLANET;

/**
 * @author Lutho Mbooi
 * @version P07_2023
 * @since 2024
 *
 */
public class Orbiter extends Spaceship implements SpaceshipVehicle {

	 private E_PLANET planet;
	/**
	 * @param manned
	 
	 */
	public Orbiter(boolean manned) {
		super(manned);
	
	}

	/**
	 * @return the planet
	 */
	public E_PLANET getPlanet() {
		return planet;
	}

	/**
	 * @param planet 
	 * 			the planet to set
	 */
	public void setPlanet(E_PLANET planet) {
		this.planet = planet;
	}
	
	@Override
	public void fly() {
		
		System.out.println("Orbiter spaceship is Currently flying to orbit around " + planet);
	}

}
