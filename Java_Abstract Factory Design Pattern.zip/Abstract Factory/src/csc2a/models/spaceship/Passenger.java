/**
 * 
 */
package csc2a.models.spaceship;

/**
 * @author Lutho Mbooi
 * @version P07
 * @since 2023
 * 
 *
 */
public class Passenger extends Spaceship implements SpaceshipVehicle {

	private int numPassengers; 
	/**
	 * @param manned
	 
	 * 
	 */
	public Passenger(boolean manned) {
		super(manned);
	
	}
	/**
	 * 
	 * @return numPassengers
	 */
	
	public int getNumPassengers() {
        return numPassengers;
    }
	/**
	 * 
	 * @param numPassengers
	 */

    public void setNumPassengers(int numPassengers) {
        this.numPassengers = numPassengers;
    } 
    

	@Override
	public void fly() {
		
		System.out.println("Passenger spaceship is flying with " + numPassengers + " passengers on board");

	}
	

}
