
package csc2a.models.spaceship;

/**
 * @author Lutho Mbooi
 * @version P07
 * @since 2023
 * 
 *
 */
public abstract class Spaceship {
	
	private boolean manned;
	
	/**
	 * 
	 * @param manned
	 */
	
	public Spaceship(boolean manned)
	{
		this.manned = manned;
	}

	
	
	/**
	 * @return the manned
	 */
	public boolean isManned() {
		return manned;
	}

	/**
	 * @param manned the manned to set
	 */
	public void setManned(boolean manned) {
		this.manned = manned;
	}
	

}
