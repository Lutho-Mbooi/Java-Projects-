/**
 * 
 */
package csc2a.models.rover;

/**
 * @author Lutho Mbooi
 * @version P07
 * @since 2023
 * 
 *
 */
public class VenusPathfinder extends Rover implements RoverVehicle {

	private int temp;
    private double atmosphericPressure;
    
	/**
	 * @param hasWeaponMounts
	 * @param hasArmourPlating
	 * @param planet
	 */
	public VenusPathfinder(E_PLANET planet,boolean hasArmourPlating,boolean hasWeaponMounts ) {
		super(planet, hasArmourPlating, hasWeaponMounts);
		
	}

	/**
	 * @return the temp
	 */
	public int getTemp() {
		return temp;
	}

	/**
	 * @param temp the temp to set
	 */
	public void setTemp(int temp) {
		this.temp = temp;
	}

	/**
	 * @return the atmosphericPressure
	 */
	public double getAtmosphericPressure() {
		return atmosphericPressure;
	}

	/**
	 * @param atmosphericPressure
	 *                the atmosphericPressure to set
	 */
	public void setAtmosphericPressure(double atmosphericPressure) {
		this.atmosphericPressure = atmosphericPressure;
	}
	
	@Override
	public void drive() {
	System.out.println("Currently Driving a Venus-Path-Finder, Temperature is "+ temp + " Atmospheric Pressure is "+ atmosphericPressure);

	}

}
