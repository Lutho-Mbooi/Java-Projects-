/**
 * 
 */
package csc2a.models.rover;

/**
 * @author Lutho Mbooi
 * @version P07
 * @since 2023
 * 
 *
 */
public class EarthTraveller extends Rover implements RoverVehicle {
	
	 private int ATVClass;

	/**
	 * @param hasWeaponMounts
	 * @param hasArmourPlating
	 * @param planet
	 * 
	 */

	public EarthTraveller(E_PLANET planet, boolean hasArmourPlating, boolean hasWeaponMounts) {
		super(planet, hasArmourPlating, hasWeaponMounts);
		
	}

	/**
	 * @return the aTVClass
	 */
	public int getATVClass() {
		return ATVClass;
	}




	/**
	 * @param aTVClass the aTVClass to set
	 */
	public void setATVClass(int aTVClass) {
		ATVClass = aTVClass;
	}

	
	@Override
	public void drive() {
		// TODO Auto-generated method stub
		System.out.println(" Currently Driving EarthTraveller Rover with ATVClass " + ATVClass);

	}
}
