/**
 * 
 */
package csc2a.models.rover;

/**
 * @author Lutho Mbooi
 * @version P07
 * @since 2023
 * 
 *
 */
public class MercuryExplorationRover extends Rover implements RoverVehicle {

	
	private int temp;
    private int numMinerals; 
    
    
	/**
	 * @param hasWeaponMounts
	 * @param hasArmourPlating
	 * @param planet
	 * 
	 */
	public MercuryExplorationRover(E_PLANET planet,boolean hasArmourPlating,boolean hasWeaponMounts ) {
		super(planet, hasArmourPlating, hasWeaponMounts);
	}


	/**
	 * @return the temp
	 */
	public int getTemp() {
		return temp;
	}



	/**
	 * @param temp the temp to set
	 */
	public void setTemp(int temp) {
		this.temp = temp;
	}



	/**
	 * @return the numMinerals
	 */
	public int getNumMinerals() {
		return numMinerals;
	}



	/**
	 * @param numMinerals the numMinerals to set
	 */
	public void setNumMinerals(int numMinerals) {
		this.numMinerals = numMinerals;
	}
	
	
	@Override
	public void drive() {
		// TODO Auto-generated method stub
		 System.out.println("Currently Driving Mercury-Exploration-Rover with temperature " + temp + " and " + numMinerals + " minerals");

	}

}
