/**
 * 
 */
package csc2a.models.rover;

/**
 * @author Lutho Mbooi
 * @version P07
 */
public enum E_PLANET {
	Earth,
	Mars,
	Mercury,
	Venus
}
