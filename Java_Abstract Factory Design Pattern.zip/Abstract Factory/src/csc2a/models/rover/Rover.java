/**
 * 
 */
package csc2a.models.rover;

/**
 * @author Lutho Mbooi
 * @version P07
 * @since 2023
 * 
 *
 */
public abstract class Rover {
	
    protected boolean hasWeaponMounts;
    protected boolean hasArmourPlating;
    protected E_PLANET planet;

    
    /**
     * 
     * @param hasWeaponMounts
     * @param hasArmourPlating
     * @param planet
     */
    public Rover(E_PLANET planet,boolean hasArmourPlating,boolean hasWeaponMounts) 
    {
        this.hasWeaponMounts = hasWeaponMounts;
        this.hasArmourPlating = hasArmourPlating;
        this.planet = planet;
    }
    
    /**
     * 
     * @return hasWeaponMounts
     */

    public boolean hasWeaponMounts() {
        return hasWeaponMounts;
    }

    public void setHasWeaponMounts(boolean hasWeaponMounts) {
        this.hasWeaponMounts = hasWeaponMounts;
    }

    /**
     * 
     * @return hasArmourPlating
     */
    public boolean hasArmourPlating() {
        return hasArmourPlating;
    }

    public void setHasArmourPlating(boolean hasArmourPlating) {
        this.hasArmourPlating = hasArmourPlating;
    }

    /**
     * 
     * @return planet
     */
    public E_PLANET getPlanet() {
        return planet;
    }

    public void setPlanet(E_PLANET planet) 
    {
        this.planet = planet;
    }

    //The Drive Method 
    public abstract void drive();
}
