/**
 * 
 */
package csc2a.models.rover;

/**
 * @author Lutho Mbooi
 * @version P07
 * @since 2023
 * 
 *
 */
public class MarsRover extends Rover implements RoverVehicle {
	
	private int numWheels;
    private int numArms;
    
	/**
	 * @param hasWeaponMounts
	 * @param hasArmourPlating
	 * @param planet
	 
	 */
    public MarsRover( E_PLANET planet,boolean hasArmourPlating,boolean hasWeaponMounts) 
    {
        super(planet, hasArmourPlating,hasWeaponMounts);
    }



	/**
	 * @return the numWheels
	 */
	public int getNumWheels() {
		return numWheels;
	}

	/**
	 * @param numWheels the numWheels to set
	 */
	public void setNumWheels(int numWheels) {
		this.numWheels = numWheels;
	}

	/**
	 * @return the numArms
	 */
	public int getNumArms() {
		return numArms;
	}

	/**
	 * @param numArms the numArms to set
	 */
	public void setNumArms(int numArms) {
		this.numArms = numArms;
	}
	
	@Override
	public void drive() {
		
		System.out.println(" Currently Driving MarsRover with " + numWheels + " wheels and " + numArms + " arms");

	}

}
