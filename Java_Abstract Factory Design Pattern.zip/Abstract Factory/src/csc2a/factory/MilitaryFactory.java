/**
 * 
 */
package csc2a.factory;

import csc2a.models.rover.E_PLANET;
import csc2a.models.rover.EarthTraveller;
import csc2a.models.rover.MarsRover;
import csc2a.models.rover.MercuryExplorationRover;
import csc2a.models.rover.RoverVehicle;
import csc2a.models.rover.VenusPathfinder;
import csc2a.models.spaceship.Atmospheric;
import csc2a.models.spaceship.Orbiter;
import csc2a.models.spaceship.Passenger;
import csc2a.models.spaceship.RoverCarrier;
import csc2a.models.spaceship.SpaceshipVehicle;

/**
 * @author Lutho Mbooi
 * @version P07
 * @since 2023
 * 
 *
 */
public class MilitaryFactory implements VehicleFactory{

		@Override
	public RoverVehicle createRover(E_PLANET planet, boolean hasArmourPlating, boolean hasWeaponMounts) {
		RoverVehicle rovervehicle = null;
	       
	     
	       if(planet.equals(E_PLANET.Earth)) {
	        
	    	   rovervehicle = new EarthTraveller(planet,hasArmourPlating,hasWeaponMounts);
	       }else if(planet.equals(E_PLANET.Mars)) {
	        
	    	   rovervehicle = new MarsRover(planet,hasArmourPlating,hasWeaponMounts);
	       }else if(planet.equals(E_PLANET.Mercury)) {
	        
	    	   rovervehicle = new MercuryExplorationRover(planet, hasArmourPlating, hasWeaponMounts);
	       }else if(planet.equals(E_PLANET.Venus))
	        
	    	   rovervehicle =  new VenusPathfinder(planet, hasArmourPlating, hasWeaponMounts);
	       else {
	           System.err.print("Error 404: planet Not Found");
	       }
	    
		return rovervehicle;
	}

	@Override
	public SpaceshipVehicle createSpaceship(String type, boolean manned)
	{
		SpaceshipVehicle spaceshipvehicle = null;

        
        if(type.equals("Atmospheric")) {
          
        	spaceshipvehicle =new Atmospheric(manned);
        }else if(type.equals("Orbiter")) {
          
        	spaceshipvehicle = new Orbiter(manned);
        }else if(type.equals("Passenger")) {
        
        	spaceshipvehicle = new Passenger(manned);;
        }else if(type.equals("RoverCarrier")) {
            
        	spaceshipvehicle = new RoverCarrier(manned);
        }else {
               System.err.print("Error 404: Spaceship Not Found");
        }
  
		return spaceshipvehicle; 
	}

}
