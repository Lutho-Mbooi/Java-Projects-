/**
 * 
 */
package csc2a.factory;

import csc2a.models.rover.E_PLANET;
import csc2a.models.rover.RoverVehicle;
import csc2a.models.spaceship.SpaceshipVehicle;

/**
 * @author Lutho Mbooi
 * @version P07
 * @since 2023
 * 
 *
 */
public interface VehicleFactory {
	
	/**
	 * 
	 * @param planet
	 * @param hasArmourPlating
	 * @param hasWeaponMounts
	 * @return overVehicle instance
	 */
	RoverVehicle createRover(E_PLANET planet, boolean hasArmourPlating, boolean hasWeaponMounts);
	
	/**
	 * 
	 * @param type
	 * @param manned
	 * @return SpaceShip instance
	 */
	SpaceshipVehicle createSpaceship(String type, boolean manned);

}
