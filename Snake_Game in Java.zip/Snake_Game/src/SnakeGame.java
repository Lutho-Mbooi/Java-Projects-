import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.*;


/**
 * 
 * @author Lutho Mbooi
 * @version Simple Snake Game
 * @since 2024
 *
 */

//Inheriting from the JPanel Class and Implementing the ActionListener, KeyListene interfaces
public class SnakeGame extends JPanel implements ActionListener , KeyListener
{
	
	private class Tile
	{
		int x;
		int y;
		
		Tile(int x, int y)
		{
			this.x = x;
			this.y = y;
		}
		
	}
	
	
	int boardWidht;
	int boardHeight;
	int tileSize = 25;
	
	Tile snakeHead;
	ArrayList<Tile> snakebody;
	
	Tile Food;
	Random random;
	
	//Game logic
	Timer gameLoop;
	int velocityX;
	int velocityY;
	boolean gameOver = false;
	
	/**
	 * 
	 * @param boardWidth
	 *        --Width of the board/window where the game will be played on
	 * @param boardHeight 
	 *        --Height of the board/window where the game will be played on
	 */
	SnakeGame(int boardWidth, int boardHeight){
		this.boardHeight = boardHeight;
		this.boardWidht = boardWidth;
		setPreferredSize(new Dimension(this.boardWidht, this.boardHeight));
		setBackground(Color.BLACK);
		
		addKeyListener(this);
		setFocusable(true);
		
		snakeHead = new Tile(5,5);
		Food = new Tile(10,10);
		snakebody = new ArrayList<Tile>();
		
		random = new Random();
		placeFood();
		
		velocityX = 0;
		velocityY =0;
		
		
		gameLoop = new Timer(100,this);
		gameLoop.start();
		
		requestFocus();
		
		
	}
	/**
	 * @param g
	 *       -- The instance of the Graphics class which will be used for Painting 
	 */
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		draw(g);
	}
	
	/**
	 * 
	 * @param g
	 *     -- Draw graphics onto the board
	 */
	public void draw(Graphics g)
	{
		//Grid 
		for(int i=0;i<boardWidht/tileSize;i++) 
		{
			g.drawLine(i*tileSize,0,i*tileSize,boardHeight);
			g.drawLine(0,i*tileSize,boardWidht,i*tileSize);
			
		}
		//Food
		g.setColor(Color.RED);
		g.fillRect(Food.x* tileSize, Food.y*tileSize, tileSize,tileSize );
		
		//Snake
		g.setColor(Color.green);
		g.fillRect(snakeHead.x*tileSize,snakeHead.y*tileSize,tileSize,tileSize);
		
		//snake body
		for(int i=0; i<snakebody.size();i++) {
			Tile snakePart = snakebody.get(i);
			g.fillRect(snakePart.x*tileSize, snakePart.y*tileSize, tileSize, tileSize);
			
		}
		
		//Scoring System
		g.setFont(new Font("Arial", Font.PLAIN,16));
		if(gameOver) {
			g.setColor(Color.RED);
			g.drawString("Game Over!!: "+ String.valueOf(snakebody.size()), tileSize-16, tileSize);
			
		}else {
			g.drawString("Score: " + String.valueOf(snakebody.size()) , tileSize -16, tileSize);
			
		}
		
	}
	
	//Place the Fruit a snake will be chasing
	public void placeFood() {
		Food.x = random.nextInt(boardWidht/tileSize);
		Food.y = random.nextInt(boardHeight/tileSize);
		
	}
	
	/**
	 * 
	 * @param tile1
	 * @param tile2
	 * @return True if the Snake collides with the Game world edges
	 */
	public boolean collision(Tile tile1, Tile tile2) 
	{
		return tile1.x==tile2.x && tile1.y ==tile2.y;
	}
	
	public void move() {
		
		//eat food
		if(collision(snakeHead,Food)) {
			snakebody.add(new Tile(Food.x,Food.y));
			placeFood();
			
		}
		//Snake body
		for(int i = snakebody.size()-1;i>=0;i--) {
			Tile snakePart = snakebody.get(i);
			if(i==0) {
				snakePart.x = snakeHead.x;
				snakePart.y = snakeHead.y;
				
			}else {
				Tile prevSnakePart = snakebody.get(i-1);
				snakePart.x = prevSnakePart.x;
				snakePart.y = prevSnakePart.y;
			}
		}
		//snake head 
		
		
		snakeHead.x += velocityX;
		snakeHead.y += velocityY;
		
		//gameOver Conditions
		//1 Snake bites itself
		for(int i =0;i<snakebody.size();i++) {
			Tile snakePart = snakebody.get(i);
			if(collision(snakeHead,snakePart)) {
				gameOver = true;
			}
		}
		//2 Snake collides with the walls
		if(snakeHead.x*tileSize<0 || snakeHead.x*tileSize> boardWidht || snakeHead.y*tileSize < 0 || snakeHead.y*tileSize> boardHeight) {
			gameOver = true;
		}
		
		
	}

	
	@Override
	public void actionPerformed(ActionEvent e) {
		move();
		repaint();
		if (gameOver) {
			gameLoop.stop();
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @param e
	 *        -- Key Event Listener for game movements
	 */
	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_UP && velocityY != 1) {
			velocityX =0;
			velocityY = -1;
		}
		else if(e.getKeyCode() == KeyEvent.VK_DOWN && velocityY != -1) {
			velocityX = 0;
			velocityY =1;
		}else if(e.getKeyCode() == KeyEvent.VK_LEFT && velocityX != 1) {
			velocityX = -1;
			velocityY =0;
		}else if(e.getKeyCode() == KeyEvent.VK_RIGHT && velocityX != -1) {
			velocityX = 1;
			velocityY =0;
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	

}
