/**
 * 
 */

/**
 * @author Lutho Mbooi
 * @version Snake Game
 * @Since 21/02/2024
 *
 */

import javax.swing.*;


public class Snake {

	/**
	 * @param args
	 *       --Array of Strings from the Command Lines
	 */
	public static void main(String[] args) 
	{
		int boardWidth = 600;
		int boardHeight = 600;
	
		
		//Creating windows
		JFrame frame = new JFrame("Snake_Game");
		frame.setVisible(true);
		frame.setSize(boardWidth, boardHeight);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		
		
		 
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		SnakeGame snakeGame= new SnakeGame(boardWidth,boardHeight);
		frame.add(snakeGame);
		frame.pack();
		snakeGame.requestFocus();
		

	}

}
